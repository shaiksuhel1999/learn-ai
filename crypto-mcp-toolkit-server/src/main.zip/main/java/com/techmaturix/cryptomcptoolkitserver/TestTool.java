package com.techmaturix.cryptomcptoolkitserver;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.stereotype.Service;

@Service
public class TestTool {

    @Tool(name = "hello", description = "Test hello tool")
    public String hello() {
        return "Hello from MCP tool!";
    }

}
