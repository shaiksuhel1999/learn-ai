package com.techmaturix.cryptomcptoolkitserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CryptoMcpToolkitServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CryptoMcpToolkitServerApplication.class, args);
	}

}
